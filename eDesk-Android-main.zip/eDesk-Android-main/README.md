# eDesk-Android
 This is a Android Project for Complete Online Complain, Suggestion, Request and many more feature for any organization transparency System.
